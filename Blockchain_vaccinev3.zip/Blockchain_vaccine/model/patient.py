
class Patient:
    
#    def __init__(self,name):
#        self.name=name
#        #self.address=address
#        self.dose1=False
#        self.dose2=False
#        
#    def is_dose1_taken(self,blockchain):
#        blockchain.update_total_vaccines(self.name)
#        
#    def is_dose_2_taken(self,blockchain):
#        blockchain.update_total_vaccines(self.name)
    def dummy():
        return 0