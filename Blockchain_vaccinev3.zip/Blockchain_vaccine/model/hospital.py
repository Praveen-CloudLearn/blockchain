class Hospital:
    
#    def __init__(self,name):
#        self.name=name
#        self.block=0
#        self.vaccine=0
#        
#    def add_transaction_to_patient(self,blockchain,patient,doseno):
#        if(self.vaccine==0):
#            return -1
#        else:
#            index=blockchain.add_transaction(self.name,patient,1)
#            self.vaccine=self.vaccine-1
#            return index
#    
#    def update_total_vaccines(self,blockchain):
#        self.vaccine,index=blockchain.iterate_chain(self.name,self.block)
#        self.block=index
    
    def get_transaction_by_itemcode_LOT():
        return 0